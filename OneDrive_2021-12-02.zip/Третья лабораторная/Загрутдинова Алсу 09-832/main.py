import pandas as pd
import numpy as np
pd.set_option('display.max_rows', None)
p = 2
m = 7
summary = pd.DataFrame(columns=range(p), index=range(p))
for i in range(p):
    for j in range(p):
        summary.iloc[i, j] = (i + j) % p
summary
multiplication = pd.DataFrame(columns=range(p), index=range(p))
for i in range(p):
    for j in range(p):
        multiplication.iloc[i, j] = (i * j) % p
multiplication
# ## 2. Построить расширение и записать различные представления (многочлен, вектор, степень)
# Построим расширение поля GF(2^7) с помощью следующего примитивного полинома:
polinomprim = np.poly1d([1, 0, 0, 0, 1, 0, 0, 1])
print(polinomprim)
# Для данного многочлена примитивным элементом является x.
# Примитивный элемент поля GF(2^7) имеет порядок 128-1 = 127. 127 - простое число, поэтому все ненулевые элементы поля имеют максимальный порядок и могут быть порождающими. Наименьший элемент = 2, что соответствует x в предсталении в виде многочлена.
# Построим расширение поля GF(2^7) с помощью примитивного многочлена и представим в виде степени, вектора и многочлена.
# нахождение остатка от деления полиномов
def mod_pol(pol1, pol2):
    return np.poly1d((np.array(np.polydiv(pol1, pol2)[1]) % 2).astype('int'))
def get_poly_from_deg(deg):
    return np.poly1d([1] + [0] * deg)
def fill_pol(pol, n):
    return [0] * (n - pol.order) + list(pol.c)
# построение расширенного поля
def buildfield(field_prim, elnumer):
    polinom = [get_poly_from_deg(n) for n in range(elnumer - 1)]
    return [np.poly1d([0])] + [mod_pol(pol, field_prim) for pol in polinom]
# сумма полиномов
def sum_pol(pol1, pol2):
    return np.poly1d((np.array(pol1 + pol2) % 2).astype('int'))
def to_poly_form(coef):
    poly = ""
    if coef[0] == 1:
        poly += "1"
    for i in range(1, len(coef)):
        if coef[i] != 0:
            if poly != "":
                poly += "+"
            poly += f"x^{i}"
    return poly if len(poly) > 0 else "0"
# поле
class Field:
    def __init__(self, base):
        self.base = base
        self.elements = []
# расширенное поле
class ExtendedField:
    def __init__(self, base, deg, primitive_poly):
        self.base = base
        self.deg = deg
        self.primitive_poly = primitive_poly
        self.elements = []
    def get_elements(self):
        self.elements = [FieldElement(i, self) for i in range(self.base ** self.deg)]
        return self.elements
class FieldElement:
    def __init__(self, num: int, field: ExtendedField):
        self.element = num
        self.field = field
        self.degree = self.to_degree(num)
        self.vector, self.poly = self.from_deg(self.degree)
    def to_vector(self, num):
        newNum = ''
        while num > 0:
            newNum = str(num % self.field.base) + newNum
            num //= self.field.base
        vector = [0] * (self.field.deg - len(newNum)) + [int(i) for i in newNum]
        return vector

    def from_deg(self, deg):
        degree = deg
        if deg == np.inf:
            vector = np.array([0] * self.field.deg)
            poly = np.poly1d(vector)
        elif deg == 0:
            vector = np.array([0] * (self.field.deg - degree - 1) + [1])
            poly = np.poly1d(vector)
        elif degree < self.field.deg:
            vector = np.array([0] * (self.field.deg - degree - 1) + [1] + [0] * (degree))
            poly = np.poly1d(vector)
        else:
            vector = [1] + [0] * (degree)
            pol = np.poly1d(vector)
            vector = np.array(fill_pol(mod_pol(pol, self.field.primitive_poly), self.field.deg - 1))
            poly = np.poly1d(vector)
        return vector, poly

    def vector2num(self, vect):
        for el in self.field.elements:
            if el.vector == vect:
                return el.vector
        return None

    def to_poly(self, num):
        if type(self.vector) != None:
            poly = np.poly1d(self.vector)
        else:
            poly = np.poly1d(self.to_vector(num))
        return poly

    def to_degree(self, num):
        return np.inf if num == 0 else num - 1

    # сложение через векторное представление
    def dobav(self, el2):
        vector1 = (self.vector + el2.vector) % 2
        for el in self.field.elements:
            if (el.vector == vector1).all():
                return el
        return None
    def clog(self, el2):
        deg = (self.degree + el2.degree) % (self.field.base ** self.field.deg - 1)
        for el in self.field.elements:
            if el.degree == deg:
                return el
        return None
    # деление
    def poi(self, el2):
        if self.degree < el2.degree:
            raise Exception

        deg = (self.degree - el2.degree) % (self.field.base ** self.field.deg - 1)
        for el in self.field.elements:
            if el.degree == deg:
                return el
        return None
f = ExtendedField(2, 7, polinomprim)
f.get_elements()

el_dict = {'vectors': [], 'poly': [], 'degrees': []}
for i in range(2 ** 7):
    el = FieldElement(i, f)
    el_dict['vectors'].append("".join(map(str, el.vector)))
    el_dict['poly'].append(to_poly_form(el.poly.c[::-1]))
    el_dict['degrees'].append(f'a^{el.degree}')
pd.DataFrame(el_dict)
# Таблица логарифмов:
polinomi = []
znach = []
polinomtwo = {}
for i, lomi in enumerate(buildfield(polinomprim, p ** m)):
    field = fill_pol(lomi, m - 1)
    polinomi.append(field)

    znak = 0
    if i == 0:
        # print('inf')
        znach.append(np.inf)
        znak = np.inf
    else:
        # print(f'a_{i-1}')
        znach.append(i - 1)
        znak = i - 1
    polinomtwo["".join(map(str, field))] = znak
z_i = []
for znak, lomi in zip(znach, polinomi):
    z = fill_pol(sum_pol(np.poly1d(lomi), np.poly1d([1])), m - 1)
    z_i.append(polinomtwo["".join(map(str, z))])
import pandas as pd
logarifm = pd.DataFrame({'i': znach, 'z(i)': z_i})
logarifm



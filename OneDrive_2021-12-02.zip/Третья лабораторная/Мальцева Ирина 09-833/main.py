#!/usr/bin/env python
# coding: utf-8

# ## Вариант 12

# Для заданного варианта p = 12 mod 5 = 2, m = 7

# In[1]:


import pandas as pd
import numpy as np
pd.set_option('display.max_rows', None)

p=2
m=7


# ## 1. Построить конечное поле

# Элементами поля GF(2) являются 0 и 1. Приведем таблицы сложения и умножения элементов поля.

# In[2]:


sum_table = pd.DataFrame(columns = range(p), index = range(p))

for i in range(p):
    for j in range(p):
        sum_table.iloc[i, j] = (i + j) % p

print("Таблица сложения: ")
sum_table


# In[3]:


mult_table = pd.DataFrame(columns = range(p), index = range(p))

for i in range(p):
    for j in range(p):
        mult_table.iloc[i, j] = (i * j) % p

print("Таблица умножения: ")
mult_table


# ## 2. Построить расширение и записать различные представления (многочлен, вектор, степень)

# Построим расширение поля GF(2^7) с помощью следующего примитивного полинома:

# In[4]:


primitive_poly = np.poly1d([1, 0, 0, 0, 1, 0, 0, 1])
print(primitive_poly)


# Для данного многочлена примитивным элементом является x. 

# Примитивный элемент поля GF(2^7) имеет порядок 128-1 = 127. 127 - простое число, поэтому все ненулевые элементы поля имеют максимальный порядок и могут быть порождающими. Наименьший элемент = 2, что соответствует x в предсталении в виде многочлена.

# Построим расширение поля GF(2^7) с помощью примитивного многочлена и представим в виде степени, вектора и многочлена.

# In[5]:


# нахождение остатка от деления полиномов
def mod_pol(pol1, pol2):
    return np.poly1d((np.array(np.polydiv(pol1, pol2)[1]) % 2).astype('int'))

def get_poly_from_deg(deg):
    return np.poly1d([1] + [0] * deg)

def fill_pol(pol, n):
    return  [0] * (n - pol.order) + list(pol.c)

# построение расширенного поля
def get_poly_field(primitive_poly, num_elements):
    polynoms = [get_poly_from_deg(n) for n in range(num_elements-1)]
    return [np.poly1d([0])] + [mod_pol(pol, primitive_poly) for pol in polynoms]

# сумма полиномов
def sum_pol(pol1, pol2):
    return np.poly1d((np.array(pol1 + pol2) % 2).astype('int'))

def to_poly_form(coef):
    poly = ""
    if coef[0] == 1:
        poly += "1"
    
    for i in range(1, len(coef)):
        if coef[i] != 0:
            if poly != "":
                poly += "+"
            poly += f"x^{i}"
    return poly if len(poly) > 0 else "0"


# In[6]:


# поле
class Field:
    def __init__(self, base):
        self.base = base
        self.elements = []

# расширенное поле
class ExtendedField:
    def __init__(self, base, deg, primitive_poly):
        self.base = base
        self.deg = deg
        self.primitive_poly = primitive_poly
        self.elements = []
        
    def get_elements(self):
        self.elements = [FieldElement(i, self) for i in range(self.base ** self.deg)]
        return self.elements

class FieldElement:
    def __init__(self, num: int, field: ExtendedField):
        self.element = num
        self.field = field
        self.degree = self.to_degree(num)
        self.vector, self.poly = self.from_deg(self.degree)
        
    def to_vector(self, num):
        newNum = ''
        while num > 0:
            newNum = str(num % self.field.base) + newNum
            num //= self.field.base
        vector = [0] * (self.field.deg - len(newNum)) + [int(i) for i in newNum]
        return vector
    
    def from_deg(self, deg):
        degree = deg
        if deg == np.inf:
            vector = np.array([0] * self.field.deg)
            poly = np.poly1d(vector)
        elif deg == 0:
            vector = np.array([0] * (self.field.deg - degree - 1) + [1])
            poly = np.poly1d(vector)
        elif degree < self.field.deg:
            vector = np.array([0] * (self.field.deg - degree - 1) + [1] +  [0] * (degree))
            poly = np.poly1d(vector)
        else:
            vector = [1] +  [0] * (degree)
            pol = np.poly1d(vector)
            vector = np.array(fill_pol(mod_pol(pol, self.field.primitive_poly), self.field.deg-1))
            poly = np.poly1d(vector)
        return vector, poly
    
    def vector2num(self, vect):
        for el in self.field.elements:
            if el.vector == vect:
                return el.vector
        return None
    
    def to_poly(self, num):
        if type(self.vector) != None:
            poly = np.poly1d(self.vector)
        else:
            poly = np.poly1d(self.to_vector(num))
        return poly
    
    def to_degree(self, num):
        return np.inf if num == 0 else num-1
    
    # сложение через векторное представление
    def __add__(self, el2):
        vec = (self.vector + el2.vector) % 2
        for el in self.field.elements:
            if (el.vector == vec).all():
                return el
        return None
    
    # умножение через представление в виде степени
    def __mul__(self, el2):
        deg = (self.degree + el2.degree) % (self.field.base**self.field.deg-1)
        for el in self.field.elements:
            if el.degree == deg:
                return el
        return None
    
    # возведение в степень
    def __pow__(self, power):
        if self.degree == 1:
            return self
        
        deg = (power * self.degree) % (self.field.base**self.field.deg-1)
        for el in self.field.elements:
            if el.degree == deg:
                return el
        return None
    
    # деление
    def __truediv__(self, el2):
        if self.degree < el2.degree:
            raise Exception

        deg = (self.degree - el2.degree) % (self.field.base**self.field.deg-1)
        for el in self.field.elements:
            if el.degree == deg:
                return el
        return None


# In[7]:


f = ExtendedField(2, 7, primitive_poly)
f.get_elements()

el_dict = {'vectors':[], 'poly':[], 'degrees':[]}
for i in range(2**7):
    el = FieldElement(i, f)
    el_dict['vectors'].append("".join(map(str, el.vector)))
    el_dict['poly'].append(to_poly_form(el.poly.c[::-1]))
    el_dict['degrees'].append(f'a^{el.degree}')


# Построенное поле через различные представления:

# In[8]:


pd.DataFrame(el_dict)


# Таблица логарифмов: 

# In[9]:


polynoms = []
degrees = []
pol2deg = {}
for i, pol in enumerate(get_poly_field(primitive_poly, p**m)):
    poly = fill_pol(pol, m-1)
    polynoms.append(poly)
    
    deg = 0
    if i == 0:
        #print('inf')
        degrees.append(np.inf)
        deg = np.inf
    else:
        #print(f'a_{i-1}')
        degrees.append(i-1)
        deg = i-1
    
    pol2deg["".join(map(str, poly))] = deg
    
z_i = []
for deg, pol in zip(degrees, polynoms):
    z = fill_pol(sum_pol(np.poly1d(pol), np.poly1d([1])), m-1)
    z_i.append(pol2deg["".join(map(str, z))])


# In[10]:


import pandas as pd

log_table = pd.DataFrame({'i':degrees, 'z(i)':z_i})
log_table


# ## 3. Привести примеры операций над элементами поля

# Операции будем проводить над 2 и 10 элементами в расширенном поле

# In[11]:


f = ExtendedField(2, 7, primitive_poly)
f.get_elements()

el1 = FieldElement(2, f)
el2 = FieldElement(10, f)


# Различные представления элементов:

# In[12]:


print(f"В виде вектора: {el1.vector}, {el2.vector}")


# In[13]:


print(f"В виде многочлена:\n {el1.poly}, \n{el2.poly}")


# In[14]:


print(f"В виде степени примитивного элемента: x^{el1.degree}, x^{el2.degree}")


# Сложение элементов (производится через векторное представление)

# In[15]:


sum_el = el1 + el2
sum_el.vector


# In[16]:


print(f"Другие представления суммы: \nМногочлен:\n{sum_el.poly}, \nСтепень: x^{sum_el.degree}")


# Сложение через таблицу логарифмов:

# In[17]:


q = p**m - 1
sum_deg = (el1.degree + log_table[log_table['i'] == (el2.degree-el1.degree)]['z(i)']).item() % q
sum_el_2 = FieldElement(int(sum_deg)+1, f)
print(f"Степень: x^{sum_el_2.degree}")
print(f"Вектор: {sum_el_2.vector}")
print(f"Многочлен: \n{sum_el_2.poly}")


# Умножение элементов (производится через представление в виде степени)

# In[18]:


mul_el = el1 * el2
print(f"x^{mul_el.degree}")


# In[19]:


print(f"Другие представления произведения: \nмногочлен:\n{mul_el.poly}, \nвектор:{mul_el.vector}")


# Возведение в степень:

# In[20]:


el = el2**2
print(f"Степень: x^{el.degree}")
print(f"Многочлен: \n{el.poly}")
print(f"Вектор: {el.vector}")


# Деление: 

# In[21]:


el = (el2 / el1)
print(f"Степень: x^{el.degree}")
print(f"Многочлен: \n{el.poly}")
print(f"Вектор: {el.vector}")


import numpy as np
const = 13;
add = np.zeros(const*const).reshape(const,const)
mul = np.zeros(const*const).reshape(const,const)
for i in range(const):
    for j in range(const):
        add[i,j]=(i+j)%const
for i in range(const):
    for j in range(const):
        mul[i,j]=(i*j)%const
print(add)
print(mul)
def sum(a,b):
    ba = ''
    bb = ''
    while a > 0:
        ba = str(a % 2) + ba
        a = a // 2
    while b > 0:
        bb = str(b % 2) + bb
        b = b // 2
    ba=ba.zfill(4)
    bb=bb.zfill(4)
    bat = ba[::-1]
    bbt = bb[::-1]
    r=0
    res=list(bat)
    for i in range(4):
        if (bat[i]!=bbt[i]):
            r=r+2**i
            res[i]=1
        else:
            res[i]=0
    print(res)
    return r
def mul(a,b):
    ba = ''
    bb = ''
    while a > 0:
        ba = str(a % 2) + ba
        a = a // 2
    while b > 0:
        bb = str(b % 2) + bb
        b = b // 2
    ba=ba.zfill(4)
    bb=bb.zfill(4)
    bat=[int(i) for i in ba]
    bbt=[int(i) for i in bb]
    res = [0] * (len(bat) + len(bbt) - 1)
    for o1, i1 in enumerate(bat):
        for o2, i2 in enumerate(bbt):
            res[o1 + o2] += i1 * i2
    for i in res:
        res[i]=res[i]%2
    res.reverse()
    n=len(res)
    pol=[1,1,1]
    z=4
    c=0
    while not (z == n):
        divisor = res[c] / pol[0]
        for i in range(len(pol)):
            rem = res[i+c] - pol[i] * divisor
            res[i+c] = int(rem)
        z = z + 1
        for i in range(n):
            if(res[i]!=0):
                c=i
                break
    res.reverse()
    r=0
    for i in range(len(res)):
        if(res[i]!=0):
            r=r+2**i
    print(res)
    return r
def coef(a):
    bat=[1]
    for i in range(a):
        bat.append(0)
    res = bat
    n=len(res)
    pol=[1,1,1]
    z=3
    c=0
    if n>=len(pol):
        while( not (z == n)) and (n-c>=len(pol)):
            divisor = res[c] / pol[0]
            for i in range(len(pol)):
                rem = res[i+c] - pol[i] * divisor
                res[i+c] = int(rem)
            z = z + 1
            for i in range(c,n):
                if(res[i]!=0):
                    c=i
                    break
    res.reverse()
    for i in range(len(res)):
        if(res[i]==-1):
            res[i]=1
    while (len(res)<8):
        res.append(0)
    while (len(res)>8):
        res.pop(len(res)-1)
    return res
for i in range(const*const):
    print('степень а^'+str(i)+',многочлен'+str(coef(i)))
print(sum(5,3))
print(mul(5,3))
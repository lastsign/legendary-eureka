import random
from func import GFp, GFpm
p = 5
m = 3
gf5 = GFp(p)
print ("Таблица сложения для поля GF(5): \n    0, 1, 2, 3, 4", "\n  ------------------")
for i in range(p):
    print (f"{i}| {gf5.sums[i]}")

print ("Таблица умножения для поля GF(5): \n    0, 1, 2, 3, 4", "\n  ------------------")
for i in range(p):
    print (f"{i}| {gf5.mults[i]}")
gf53 = GFpm(p, m)

random_a = random.choice(gf53.els)
random_b = random.choice(gf53.els)
print(f"Случайные элементы поля\nв виде векторов- {random_a} и {random_b}"
      f"\nв виде полиномов - {gf53.v_in_pol(random_a)} и {gf53.v_in_pol(random_b)}"
      f"\nв виде степеней - x^{gf53.v_in_deg(random_a)} и x^{gf53.v_in_deg(random_b)}")
print(f"\nПример операции\nсложения: {gf53.v_in_pol(random_a)} + {gf53.v_in_pol(random_b)} = "
      f"{gf53.v_in_pol(gf53.sum(random_a, random_b))}")
print(f"или: {random_a} + {random_b} = "
      f"{gf53.sum(random_a, random_b)}")
print(f"или: x^{gf53.v_in_deg(random_a)} + x^{gf53.v_in_deg(random_b)} = "
      f"x^{gf53.v_in_deg(gf53.sum(random_a, random_b))}")

print(f"\nумножения: {gf53.v_in_pol(random_a)} * {gf53.v_in_pol(random_b)} = "
      f"{gf53.v_in_pol(gf53.mult(random_a, random_b))}")
print(f"или: {random_a} * {random_b} = "
      f"{gf53.mult(random_a, random_b)}")
print(f"или: x^{gf53.v_in_deg(random_a)} * x^{gf53.v_in_deg(random_b)} = "
      f"x^{gf53.v_in_deg(gf53.mult(random_a, random_b))}")

print("Все элементы:")
with open("tki3.txt", 'w') as f:
    for el in gf53.els[1:]:
        f.write(f"x^{str(gf53.v_in_deg(el)).ljust(3)} or {el}  or {gf53.v_in_pol(el)}\n")
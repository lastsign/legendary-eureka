import numpy as np


class GFp():
    def __init__(self, p):
        self.p = p
        self.els = np.arange(p)
        self.sums = self.GF_sum(p, self.els)
        self.mults = self.GF_mult(p, self.els)

    def GF_sum(self, p, els):
        sums = np.zeros([p, p])
        for i in range(p):
            sums[i] = (els + i) % p
        return sums

    def GF_mult(self, p, els):
        mults = np.zeros([p, p])
        for i in range(p):
            mults[i] = (els * i) % p
        return mults


class GFpm():
    def __init__(self, p, m):
        self.p = p
        self.m = m
        self.els = GFp(p).els
        self.els = [[i, j, k] for i in self.els for j in self.els for k in self.els]
        self.degrees = self.degree()
        self.Zech_table = self.Zech()

    def v_in_pol(self, a):
        # из вектора в полином
        x = list(a)
        inf_pol = ''
        for i in range(len(x) - 1):
            if str(x[i]) != '0':
                if str(x[i] != '1'):
                    inf_pol += f"{x[i]}x^{len(x) - i - 1}+"
                else:
                    inf_pol += f"x^{len(x) - i - 1}+"
        inf_pol = inf_pol if str(x[-1]) == '0' else inf_pol + f'{x[-1]}+'
        return inf_pol[:-1]


    def v_in_deg(self, v):
        # из вектора в степень
        return self.degrees.index(v) - 1


    def degree(self):
        degree = []
        degree.append([0, 0, 0]) #  полный ноль
        degree.append([0, 0, 1]) # 0 degree
        degree.append([0, 1, 0]) # 1
        degree.append([1, 0, 0]) # 2
        degree.append([0, 2, 3]) # 3
        for i in range(5, 125):
            newdegree = [degree[i-1][1], degree[i-1][2], 0]
            newdegree[1] = (newdegree[1] + degree[4][1] * degree[i-1][0]) % self.p
            newdegree[2] = (newdegree[2] + degree[4][2] * degree[i-1][0]) % self.p
            degree.append(newdegree)
        return degree


    def Zech(self):
        els = self.els
        els2 = []
        for i in range(len(self.degrees)):
            els2.append("".join([str(self.degrees[i][j]) for j in range(self.m)]))
        dict_ai = dict()
        dict_ai[els2[0]] = float('inf')
        for i in range(1, len(els2)):
            dict_ai[els2[i]] = i-1
        dict_iz = dict.fromkeys(dict_ai.values())
        for k in dict_ai.keys():
            if dict_ai[k] != float('inf'):
                newk = k[:-1] + str((int(k[-1]) + 1) % self.p)
                dict_iz[dict_ai[k]] = dict_ai[newk]
            else:
                dict_iz[dict_ai[k]] = 0

        self.Zech_print(dict_ai, dict_iz)

        return dict_iz

    def Zech_print(self, dict_ai, dict_iz):
        print("Таблица логарифмов Zech:")
        print(" x^i   i  z(i)")
        for k in dict_ai.keys():
            if dict_ai[k] != float('inf'):
                print(k, ' ', dict_ai[k], '   ', dict_iz[dict_ai[k]])
            else:
                print(k, ' ', dict_ai[k], ' ', dict_iz[dict_ai[k]])

    def sum(self, a, b):
        c = []
        for x,y in zip(a,b):
            c.append((x + y) % self.p)
        return c

    def mult(self, a, b):
        c = self.degrees[(self.v_in_deg(a) + self.v_in_deg(b) + 1)%(self.p**self.m - 1)]
        return list(map(int,c))
import numpy as np
N=6
p=3
m=4
primtive_poly = np.poly1d([1,0,0,1,2])
elements = np.arange(p)
table_add,table_multi=np.zeros((p,p)),np.zeros((p,p))
for i in range(p):
    for j in range(p):
         table_add[i][j]=(i+j)%p
         table_multi[i][j]=(i*j)%p
print('GF(p)-сложение'.format(p))
print(table_add)
print('GF(p)-умнжение'.format(p))
print(table_multi)

GF={0:np.poly1d([0,0,0,1]),
    1:np.poly1d([0,0,1,0]),
    2:np.poly1d([0,0,1,1])}
for i in range(1,p**m):
    div,mod=np.polydiv((np.polymul(GF[i-1],GF[1])),primtive_poly)
    GF[i]=np.poly1d(np.mod(mod,3).astype(int))
print(GF)

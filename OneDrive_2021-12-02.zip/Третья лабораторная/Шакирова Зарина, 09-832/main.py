import numpy as np


class Field:
    def __init__(self, p):
        self.p = p
        self.elements = []
        for i in range(p):
            self.elements.append(i)

    def sum(self):
        print("Таблица сложения \n")
        print ("+ |", self.elements)
        print("________________")
        for i in range(self.p):
            s = str(self.elements[i]) + " |  "
            for j in range(self.p):
               s += str((self.elements[i] + self.elements[j]) % self.p) + "  "
            print(s)

    def mult(self):
        print("Таблица умножения \n")
        print("x |", self.elements)
        print("________________")
        for i in range(self.p):
            s = str(self.elements[i]) + " |  "
            for j in range(self.p):
               s += str((self.elements[i] * self.elements[j]) % self.p) + "  "
            print(s)


class Ext_Field:
    def __init__(self, p, m, prim_pol):
        self.p = p
        self.m = m
        self.prim_pol = prim_pol
        self.elements = []
        for i in range(self.p ** self.m):
            self.elements.append(F_Element(i, self))


class F_Element:
    def __init__(self, num, field):
        self.num = num
        self.field = field
        self.exp = self.to_exp(num)
        self.pol, self.vec = self.from_exp(self.exp)

    def to_vec(self, num):
        s = ""
        while num > 0:
            s = str(num % self.field.p) + s
            num //= self.field.p
        v = [0] * (self.field.p - len(s)) + [int(i) for i in s]
        return v

    def to_pol(self, num):
        pol = np.poly1d(self.to_vec(num))
        return pol

    def to_exp(self, num):
        if num == 0:
            return np.inf
        else:
            return num-1

    def from_exp(self, exp):
        if exp == np.inf:
            vec = np.array([0] * self.field.m)
            pol = np.poly1d(vec)
        elif exp == 0:
            vec = np.array([0] * (self.field.m - exp - 1) + [1])
            pol = np.poly1d(vec)
        elif exp < self.field.m:
            vec = np.array([0] * (self.field.m - exp - 1) + [1] + [0] * exp)
            pol = np.poly1d(vec)
        else:
            vec = [1] + [0] * exp
            pol = np.poly1d(vec)
            vec = np.array(help_func(pols_mod(pol, self.field.prim_pol), self.field.m - 1))
            pol = np.poly1d(vec)
        return pol, vec

    def sum(self, el2):
        vec = (self.vec + el2.vec) % 2
        for elem in self.field.elements:
            if (elem.vec == vec).all():
                return elem
        return None


def pols_mod(pol1, pol2):
    return np.poly1d((np.array(np.polydiv(pol1, pol2)[1]) % 2).astype('int'))


def help_func(pol, n):
    res = [0] * (n - pol.order) + list(pol.c)
    return res


if __name__ == "__main__":
    t = Field(2)
    t.sum()
    t.mult()

    F = Ext_Field(2, 7, [1, 0, 0, 0, 1, 0, 0, 1])
    '''print("Построенное поле:")
    for i in range(len(F.elements)):
        print("№", i, "\n   vector:", F.elements[i].vec, "\n   poly: \n", F.elements[i].pol, "\n   exponent: a^", F.elements[i].exp, "\n")'''

    print(F.elements[3].sum(F.elements[7]).vec)
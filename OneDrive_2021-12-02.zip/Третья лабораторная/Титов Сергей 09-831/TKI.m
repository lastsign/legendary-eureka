clear all;
p = 5; m = 3;
prim_poly = [2 3 0 1];
f = prim_poly;
field = gftuple([-1:p^m-2]',prim_poly,p)

k1 = zeros(125,1);
for i=1:p^m
    temp =join([num2str(field(i,1)),num2str(field(i,2)),num2str(field(i,3))]);
    %temp = fprintf('%x',num2str(temp))
    k1(i,1)=string(num2str(temp));
end;

syms x 
z = {}
for k=1:p^m
    element=poly2sym(field(k,:));
    z = [z,element];
end;
tr = reshape([1:125],[125,1]);
Polinom = reshape(z,[125,1]);
A = table(string(Polinom),k1,tr,string(log(Polinom)));
A.Properties.VariableNames = {'Полином','Вектор','Степень а','log'}

C = gfadd([2 3 2],[1 2 4],5)


G = gfmul([2 3 2],[1 2 4],5)
%n = 12;
%fprintf('%03d', n)


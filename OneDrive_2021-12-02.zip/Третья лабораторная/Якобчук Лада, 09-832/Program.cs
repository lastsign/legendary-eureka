﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstLabHemming
{
    class Program
    {
        static void Main(string[] args)
        {
            #region GaluaField

            GaluaField gf = new GaluaField(11);
            Console.WriteLine(gf.ToString());

            Console.WriteLine();
            gf.PrintAdditionTable();

            Console.WriteLine();
            gf.PrintMultiplicationTable();

            #endregion

            #region EvtendedGaluaField

            ExtendedGaluaField egf = new ExtendedGaluaField();
            Console.WriteLine(egf.ToString());

            Random random = new Random(DateTime.Now.Ticks.GetHashCode());
            int firstValue = random.Next(0, 120);
            int secondValue = random.Next(0, 120);

            Console.WriteLine("First value:");
            Console.WriteLine(egf.GetPolynimialElementByIndex(firstValue) + ", " 
                + egf.GetVectorElementByIndex(firstValue) + ", " 
                + egf.GetAlphaElementByIndex(firstValue));

            Console.WriteLine("Second value:");
            Console.WriteLine(egf.GetPolynimialElementByIndex(secondValue) + ", "
                + egf.GetVectorElementByIndex(secondValue) + ", "
                + egf.GetAlphaElementByIndex(secondValue));

            Console.WriteLine(egf.AdditionOfTwoNumbers(firstValue, secondValue));
            Console.WriteLine(egf.MultiplicationOfTwoNumbers(firstValue, secondValue));            

            egf.PrintLogarithmTable();

            #endregion

            Console.ReadKey();
        }
    }
}

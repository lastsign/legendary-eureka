﻿using System;
using System.Linq;

namespace FirstLabHemming
{
    public class GaluaField
    {
        private readonly int[] elements;

        private readonly int count;

        public GaluaField(int countParameter)
        {
            count = countParameter;

            elements = new int[count];

            for (int i = 0; i < count; i++)
            {
                elements[i] = i;
            }
        }

        public void PrintAdditionTable()
        {
            int[,] table = new int[count, count];

            Console.WriteLine("Addition Table");
            Console.WriteLine("\n" + new string('-', count * 5));

            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < count; j++)
                {
                    table[i, j] = (elements[i] + elements[j]) % count;
                    Console.Write("{0, 3} |", table[i, j]);
                }
                Console.WriteLine("\n" + new string('-', count * 5));
            }
        }

        public void PrintMultiplicationTable()
        {
            int[,] table = new int[count, count];

            Console.WriteLine("Multiplication Table");
            Console.WriteLine("\n" + new string('-', count * 5));

            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < count; j++)
                {
                    table[i, j] = (elements[i] * elements[j]) % count;
                    Console.Write("{0, 3} |", table[i, j]);
                }
                Console.WriteLine("\n" + new string('-', count * 5));
            }
        }
        
        public override string ToString()
        {
            string output = String.Format("GF({0}) : ", count);
            output += "{" + String.Join("", elements.Select(x => x + ", ").ToArray());

            return output.Substring(0, output.Length - 2) + "}";
        }
    }
}

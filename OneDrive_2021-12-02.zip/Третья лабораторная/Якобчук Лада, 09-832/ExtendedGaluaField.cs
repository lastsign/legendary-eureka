﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FirstLabHemming
{
    public class ExtendedGaluaField
    {
        private readonly List<List<int>> elements;

        private const int primeBase = 11;

        private const int index = 2;

        private List<int>[,] additionTable;

        private readonly Dictionary<int, List<int>> alpha;

        public ExtendedGaluaField()
        {
            elements = new List<List<int>>();

            for (int i = 0; i < primeBase; i++)
            {
                for (int j = 0; j < primeBase; j++)
                {
                    elements.Add(new List<int>() { i, j });
                }
            }

            CountAdditionTable();

            alpha = new Dictionary<int, List<int>>
            {
                //0 = 0
                { -1, new List<int>() { 0, 0 } },
                //alpha^0 = 01
                { 0, new List<int>() { 0, 1 } },
                //alpha^1 = 10
                { 1, new List<int>() { 1, 0 } },
                //alpha^2 = 10*alpha + 4 = 104
                { 2, new List<int>() { 10, 4 } }
            };

            CountAlpha();
        }

        public string GetPolynimialElementByIndex(int elementIndex)
        {
            if (elements[elementIndex][0] != 0)
                if (elements[elementIndex][1] != 0)
                    return elements[elementIndex][0].ToString() + "x + " + elements[elementIndex][1].ToString();
                else
                    return elements[elementIndex][0].ToString() + "x";
            else
                return elements[elementIndex][1].ToString();
        }

        public string GetVectorElementByIndex(int elementIndex)
        {
            return "[ " + elements[elementIndex][0].ToString() + ", " + elements[elementIndex][1].ToString() + " ]";
        }

        public string GetAlphaElementByIndex(int elementIndex)
        {
            int alphaIndex = alpha.FirstOrDefault(x => x.Value[0] == elements[elementIndex][0] && x.Value[1] == elements[elementIndex][1]).Key;

            if (alphaIndex == -1)
                return "0";
            else
                return "alpha^" + alphaIndex;
        }

        private string GetVectorElement(List<int> element)
        {
            return "[ " + element[0].ToString() + ", " + element[1].ToString() + " ]";
        }

        public string AdditionOfTwoNumbers(int firstElementIndex, int secondElementIndex)
        {
            int count = (int)Math.Pow(primeBase, index);

            if (firstElementIndex < count && firstElementIndex >= 0 &&
                secondElementIndex < count && secondElementIndex >= 0)
                return elements[firstElementIndex][0].ToString() + elements[firstElementIndex][1].ToString() + " + "
                    + elements[secondElementIndex][0].ToString() + elements[secondElementIndex][1].ToString() + " = "
                    + additionTable[firstElementIndex, secondElementIndex][0].ToString()
                    + additionTable[firstElementIndex, secondElementIndex][1].ToString();

            return "Wrong indeces";
        }

        public string MultiplicationOfTwoNumbers(int firstElementIndex, int secondElementIndex)
        {
            int count = (int)Math.Pow(primeBase, index);

            if (firstElementIndex < count && firstElementIndex >= 0 &&
                secondElementIndex < count && secondElementIndex >= 0)
            {
                int firstIndex = alpha.FirstOrDefault(x => x.Value[0] == elements[firstElementIndex][0] && x.Value[1] == elements[firstElementIndex][1]).Key;
                int secondIndex = alpha.FirstOrDefault(x => x.Value[0] == elements[secondElementIndex][0] && x.Value[1] == elements[secondElementIndex][1]).Key;

                List<int> answer;

                if (firstIndex == -1 || secondIndex == -1)
                    answer = new List<int>() { 0, 0 };
                else
                    answer = new List<int>(alpha[(firstIndex + secondIndex) % (count - 1)]);

                return elements[firstElementIndex][0].ToString() + elements[firstElementIndex][1].ToString() + " * "
                    + elements[secondElementIndex][0].ToString() + elements[secondElementIndex][1].ToString() + " = "
                    + answer[0].ToString() + answer[1].ToString();
            }

            return "Wrong indeces";
        }

        private void CountAdditionTable()
        {
            int count = (int)Math.Pow(primeBase, index);
            additionTable = new List<int>[count, count];

            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < count; j++)
                {
                    additionTable[i, j] = new List<int>()
                    { 
                        (elements[i][0] + elements[j][0]) % primeBase, 
                        (elements[i][1] + elements[j][1]) % primeBase 
                    };
                }
            }
        }

        private void CountAlpha()
        {
            int count = (int)Math.Pow(primeBase, index);

            for (int i = 3; i < count; i++)
            {
                alpha.Add(i, new List<int>() 
                { 
                    (alpha[i - 1][0] * alpha[2][0] + alpha[i - 1][1]) % primeBase, 
                    alpha[i - 1][0] * alpha[2][1] % primeBase 
                });
            }
        }

        public void PrintLogarithmTable()
        {
            int count = (int)Math.Pow(primeBase, index);
            List<List<string>> table = new List<List<string>>();

            for (int i = -1; i < count; i++)
            {
                string z_i = alpha
                    .FirstOrDefault(x => x.Value[0] == alpha[i][0] && x.Value[1] == (alpha[i][1] + 1) % primeBase)
                    .Key.ToString();
                table.Add(new List<string>() { GetVectorElement(alpha[i]), i.ToString(), z_i });
            }

            foreach (var item in table)
            {
                Console.WriteLine("{0, 10}|{1, 4}|{2, 4}", item[0], item[1], item[2]);
            }
        }

        public override string ToString()
        {
            int count = (int)Math.Pow(primeBase, index);
            string output = String.Format("GF({0}) : ", count);
            output += "{" + String.Join("", elements.Select(x => x[0].ToString() + x[1].ToString() + ", ").ToArray());

            return output.Substring(0, output.Length - 2) + "}";
        }
    }
}

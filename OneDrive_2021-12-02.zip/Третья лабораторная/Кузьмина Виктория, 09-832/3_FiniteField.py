import numpy as np
from tabulate import tabulate


def raising(x, a, n):  # (a^x mod n)
    binary_x = f'{int(x):b}'
    r = 1
    for x_i in binary_x:
        if int(x_i) == 1:
            r = (a * r * r) % n
        else:
            r = (r * r) % n
    return r


def GF_p(p):
    elements = np.arange(p)
    table_add, table_multi = np.zeros((p, p)), np.zeros((p, p))

    for str_i in range(p):
        for col_i in range(p):
            table_add[str_i, col_i] = (elements[str_i] + elements[col_i]) % p
            table_multi[str_i, col_i] = (elements[str_i] * elements[col_i]) % p

    return elements, table_add, table_multi


def GF_pm(p, m, f_x):
    size = pow(p, m)
    elements = []
    table_add, table_multi = [], []

    for i in range(size):
        elements.append(np.array([int(num) for num in f'{int(np.base_repr(i,base=p)):0{m}d}']))
    elements = np.array(elements)

    for str_i in range(size):
        for col_i in range(size):
            table_add.append((elements[str_i] + elements[col_i]) % p)

            mul = np.polymul(elements[str_i], elements[col_i])
            _, rest = np.polydiv(mul % p, f_x)
            table_multi.append([int(x) for x in np.concatenate([np.zeros(m - len(rest)), rest % p])])

    table_add = np.reshape(table_add, (size, size, m))
    table_multi = np.reshape(table_multi, (size, size, m))
    return elements, table_add, table_multi


def GF_pm_polynom(elements):
    m = len(elements[0])
    polynoms = []
    for vec in elements:
        pol = ''
        for i in range(0, m-1):
            pol += f'{vec[i]}x^{m-1-i} + ' if vec[i] != 0 else ''

        if vec[m-1] != 0:
            pol += f'{vec[m-1]}'
        else:
            pol = pol[:-3]  # delete ' + ' in end
        polynoms.append(''.join(pol if pol != '' else '0'))

    return polynoms


def GF_pm_power(p, elements, f_x):
    m = len(elements[0])
    N = len(elements)
    powers = np.ones(N) * -1  # -1 = 0 vector (like infinity)
    alpha_1 = []

    for i in range(m):
        vec_alph = np.zeros(m)
        vec_alph[m-1-i] = 1
        powers[[k for k in range(N) if all(elements[k] == vec_alph)][0]] = i
        if i == 1:
            alpha_1 = vec_alph

    index = [k for k in range(N) if all(elements[k] == np.array((f_x[1:] * (-1)) % p))][0]
    powers[index] = m

    for i in range(m+1, N-1):
        mul = np.polymul(elements[index], alpha_1)
        _, rest = np.polydiv(mul % p, f_x)
        vec_alph = np.concatenate([np.zeros(m - len(rest)), rest % p])
        index = [k for k in range(N) if all(elements[k] == vec_alph)][0]
        powers[index] = i

    return powers


def Zeck(p, elements, powers):
    N = len(elements)
    logs = np.ones(N) * -1  # -1 = 0 vector (like infinity)

    sort_elements = elements[np.argsort(powers)]
    powers.sort()

    vec_one = np.zeros_like(elements[0])
    vec_one[-1] = 1
    for i in range(N):
        plus_one_vec = (sort_elements[i] + vec_one) % p
        logs[[k for k in range(N) if all(sort_elements[k] == np.array(plus_one_vec))][0]] = i-1

    print('alpha_i\t   i   z(i)')
    table = []
    for i in range(N):
        table.append([sort_elements[i], powers[i], logs[i]])
    print(tabulate(table))


if __name__ == '__main__':
    p = 3
    m = 4
    f_x = np.array([1, 0, 0, 1, 2])

    GF_elements, GF_table_add, GF_table_multi = GF_p(p)

    GFexp_elements, GFexp_table_add, GFexp_table_multi = GF_pm(p, m, f_x)
    # print("addition:")
    # for i, row in enumerate(GFexp_table_add):
    #     print(i, ' '.join(map(str, [vec for vec in row])))
    # print("\nmultiplication:")
    # for i, row in enumerate(GFexp_table_multi):
    #     print(i, ' '.join(map(str, [vec for vec in row])))

    GFexp_polynoms = GF_pm_polynom(GFexp_elements)
    GFexp_powers = GF_pm_power(p, GFexp_elements, f_x)

    print('Vector\t  Alpha  Polinom')
    table = []
    for i in range(len(GFexp_elements)):
        table.append([GFexp_elements[i], GFexp_powers[i], GFexp_polynoms[i]])
    print(tabulate(table))

    Zeck(p, GFexp_elements, GFexp_powers)

import numpy as np




def gf(p):
    add, mult = np.zeros((p, p)), np.zeros((p, p))
    for i in range(p):
        for j in range(p):
            add[i][j] = (i+j) % p
            mult[i][j] = (i*j) % p
    print('Сложение:\n', add)
    print('Умножение: \n', mult)

def gfpm(p, m, g):
    gf=[[0]*3]*(p**m)
    gf={ 0 : [0,0,1],
         1 : [0,1,0],
         2 : [0,10,4]}
    for i in range(3, p ** m):
        div, mod = np.polydiv((np.polymul(gf[i-1], gf[1])), g)
        gf[i] = np.mod(mod, p).astype(int)

    return gf

if __name__ == '__main__':
 g = np.array([1, 1, 7])
 p = 11
 m = 2
 gf(p)
for k,j in gfpm(p,m,g).items():
    pol=''
    if (len(j)==3):
        j=[int(j[0]),int(j[1]), int(j[2])]
        for i in range(len(j)-1):
            pol += f"{j[i]}x^{len(j) - i - 1}+"
        if (j[len(j) - 1]) == '0':
            pol = pol[:-1]
        else:
            pol += str(j[len(j) - 1])
        print(k, ') В виде степени: х^', k, 'В виде вектора: ', j, 'В виде полинома: ', pol)
    if (len(j)==2):
        j=[0,int(j[0]),int(j[1])]
        for i in range(1,len(j)-1):
            pol+= f"{j[i]}x^{len(j)-i-1}+"
        if(j[len(j)-1])=='0':
            pol = pol[:-1]
        else:
            pol+=str(j[len(j)-1])
        print(k, ') В виде степени: х^', k, 'В виде вектора: ', j, 'В виде полинома: ', pol)
    if (len(j) == 1):
        j = [0, 0, int(j)]
        pol += str(j[2])
        print(k, ') В виде степени: х^', k, 'В виде вектора: ', j, 'В виде полинома: ', pol)

        log={}
        for i in range(1,p**m-1):











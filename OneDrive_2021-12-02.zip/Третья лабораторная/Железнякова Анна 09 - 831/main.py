from sympy import *
import re

x = Symbol('x')
listOfElements = ['2100', '0001', '0010', '0100', '1000']


def addition(lst1, lst2):
    '''
    Сложение многочленов в поле GF(3)
    :param lst1: многочлен для сложения 1
    :param lst2: мнооголчен для сложения 2
    :return: лист коэффициентов суммы
    '''
    lst1 = re.findall(r'.', lst1)
    lst2 = re.findall(r'.', lst2)
    return ''.join(list(map(lambda x, y: str((int(x) + int(y)) % 3), lst1, lst2)))


def generation(element):
    temp = re.findall(r'.', element)
    d = {a: temp[a] for a in range(len(temp))}
    dTemp = {}
    for i in d.items():
        tempI = i
        if i[1] != '0':
            dTemp[tempI[0] + 1] = int(tempI[1])
    d = dTemp.copy()
    del dTemp

    if 0 not in d.keys():
        d[0] = 0

    if 1 not in d.keys():
        d[1] = 0

    for i in d.items():
        if i[0] == 4:
            d[0] = (d[0] + (2 * d[4])) % 3
            d[1] = (d[1] + (1 * d[4])) % 3
            d[4] = 0

    if 4 in d.keys():
        d.pop(4)

    print(d)
    newPoly = ['0', '0', '0', '0']
    for i, j in d.items():
        newPoly[i] = str(j)
    return ''.join(newPoly)


def multiplication(el1, el2):
    '''
    Умножение многочленов в поле
    :param el1: многочлен для сложения 1
    :param el2: мнооголчен для сложения 2
    :return: лист коэффициентов суммы
    '''

    degreeA = listOfElements.index(el1)
    degreeB = listOfElements.index(el2)

    k = (degreeA + degreeB) % 81

    return listOfElements[k]


def findPrimitive():
    '''
    Элемент a ∈ G называется примитивным элементом или генератором группы, если его
порядок ordG(a) равен порядку группы
    :return:
    '''
    org = 3 ** 4
    for i in range(2, org):
        for j in range(1, org):
            if (i ** j) % org == 1 and j == org - 1:
                print('Порядок:', i)
                break


def coefToPoly(t):
    if t == '0000':
        return '0'
    ans = []
    temp = re.findall(r'.', t)
    temp.reverse()
    for i in range(4):
        if temp[i] != '0' and i != 3:
            ans.append('{}*x^{}'.format(temp[i], 3 - i))
        elif temp[i] != '0' and i == 3:
            ans.append(temp[3])
    ans.reverse()
    return ' + '.join(ans)


for i in range(5, 81):
    listOfElements.insert(0, generation(listOfElements[0]))
listOfElements.reverse()
print('     Степень a^ %9s Вектор %10s Полином %15s' % ('', '', ''))
for i in range(len(listOfElements)):
    print('%15s %15s %20s' % (i, listOfElements[i], coefToPoly(listOfElements[i])))

    # print ('a^{1:10} {0:10} {1:10} '.format(i,listOfElements[i], coefToPoly(listOfElements[i])))

print(coefToPoly('2100') + " + " + coefToPoly('0120') + ' = ' + coefToPoly(addition('2100', '0120')))

print(coefToPoly('1222') + " * " + coefToPoly('1000') + ' = ' + coefToPoly(multiplication('2100', '0120')))


def log():
    tbl = []
    print(listOfElements)
    for i in range(len(listOfElements)):
        try:
            tbl.append(listOfElements.index(addition('1000', listOfElements[i])))
        except:
            tbl.append(1)
    print(tbl)
log()
